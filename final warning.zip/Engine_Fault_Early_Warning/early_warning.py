"""
ENGINE FAULT EARLY WARNING  -  one file, plain output, CSV only

HOW TO RUN
    python early_warning.py                          demo (one file engine_data.csv: 1000 rows, first 70% learn, last 30% test)
    python early_warning.py --data my_engine.csv     train on your CSV (needs a Fault_Label column)
    python early_warning.py --new new_readings.csv   watch NEW engine readings (sensor columns only)

COMPLETE WORKFLOW
    1. A row of sensor readings arrives from the engine.
    2. Clean it: a missing reading is replaced by the last known value (and noted);
       a reading stuck at the same value for 10 rows is noted.
    3. Compare the current row with the rows before it:
           now - 1 row ago,  now - 2 rows ago,  now - 3 rows ago,  now - 10 rows ago,
           now - average of the last 10 rows
       so we can see how fast every sensor is moving and in which direction.
    4. The trained XGBoost model turns these comparisons into a CHANCE that a fault
       will happen in the next 8 rows, and says which fault.
    5. Warning:  chance >= 50% on 3 rows in a row = WARNING
                 chance >= 80% on 2 rows in a row = CRITICAL
    6. Everything is written to CSV files in the folder 'output'.
"""
import argparse, os
from collections import deque
import warnings
import numpy as np, pandas as pd, xgboost as xgb

warnings.filterwarnings("ignore")

# ---------------- SETTINGS (you can change these) ----------------
AHEAD = 8                  # warn about faults expected within the next 8 rows
FILL_LIMIT = 3             # a missing reading is replaced by the last known value, for up to 3 rows
REASON_CHANCE = 0.30      # explain the reasons whenever the fault chance is at least 30%
SAME_LIMIT = 10            # same value for 10 rows in a row = note "check sensor"
WARN_CHANCE, WARN_ROWS = 0.50, 3
CRIT_CHANCE, CRIT_ROWS = 0.80, 2
TRAIN_PART = 0.70          # first 70% of rows teach the model, last 30% are 'new unseen engine data'
BUFFER = 14                # rows kept in memory for live monitoring (enough to look 10 rows back)
OUT = "output"
SENSORS = []               # filled automatically from the CSV


# ====================== SIMPLE DEMO DATA (whole numbers only) ======================
def make_demo_data(rows=1000, seed=38):
    """Whole-number engine data. A fault builds up slowly (12-25 rows), crosses its limit, then recovers.
    Fault 1: Fuel_Flow >= 40   Fault 2: Cylinder2_Pressure >= 100   Fault 3: Shaft_RPM >= 11   Fault 4: Ambient_Temp >= 59
    Some readings are missing and some sensors get stuck, like real data."""
    rng = np.random.default_rng(seed)
    normal = {"Shaft_RPM": (5, 1.5), "Engine_Load": (25, 1.5), "Fuel_Flow": (34, 1.8), "Air_Pressure": (45, 1.5),
              "Ambient_Temp": (55, 1.2), "Oil_Temp": (65, 1.5), "Vibration_X": (75, 1.5), "Vibration_Y": (85, 1.5),
              "Cylinder1_Pressure": (15, 1.5), "Cylinder2_Pressure": (94, 1.5)}
    faults = {1: ("Fuel_Flow", 40, {"Air_Pressure": -4}), 2: ("Cylinder2_Pressure", 100, {"Vibration_Y": 4}),
              3: ("Shaft_RPM", 11, {"Vibration_X": 4}), 4: ("Ambient_Temp", 59, {"Oil_Temp": 4})}
    names = list(normal)
    row = lambda: {s: rng.normal(*normal[s]) for s in names}
    data, queue = [], []
    while len(data) < rows:
        data += [row() for _ in range(rng.integers(12, 26))]                        # normal running
        if not queue: queue = list(rng.permutation([1, 2, 3, 4]))                    # every fault type appears evenly
        main, limit, side = faults[int(queue.pop())]
        false_alarm_drift = rng.random() < 0.3                                       # drifts but recovers, no fault
        ramp, start = int(rng.integers(12, 26)), normal[main][0]
        end = limit - 1.5 if false_alarm_drift else limit + 2.5
        for i in range(1, ramp + 1):                                                 # slow build-up
            r = row(); p = i / ramp
            r[main] = start + (end - start) * p + rng.normal(0, normal[main][1] * 0.5)
            for s, d in side.items(): r[s] += d * p
            data.append(r)
        for _ in range(0 if false_alarm_drift else int(rng.integers(4, 9))):        # the fault itself
            r = row(); r[main] = limit + 1.5 + rng.normal(0, 0.7)
            for s, d in side.items(): r[s] += d
            data.append(r)
        for i in range(5):                                                           # recovery
            r = row(); r[main] = start + (end - start) * 0.3 * (1 - (i + 1) / 5) + rng.normal(0, 0.5)
            data.append(r)
    df = pd.DataFrame(data[:rows]).round(0)
    label = np.zeros(len(df), int)
    for f, (main, limit, _) in faults.items(): label[df[main].values >= limit] = f
    for s in names:                                                                  # missing readings and stuck sensors
        df.loc[rng.random(len(df)) < 0.01, s] = np.nan
    half = int(len(df) * TRAIN_PART)
    for lo, hi in ((0, half - 20), (half, len(df) - 20)):                           # one gap + one stuck sensor in each part
        s = rng.choice(names); a = rng.integers(lo, hi); df.loc[a:a + rng.integers(3, 7), s] = np.nan
        s = rng.choice(names); a = rng.integers(lo, hi); df.loc[a:a + rng.integers(10, 16), s] = df.loc[a, s]
    df[names] = df[names].astype("Int64")                                            # whole numbers, blank = missing
    df.insert(0, "Timestamp", pd.date_range("2024-01-01 08:00:00", periods=len(df), freq="s").strftime("%Y-%m-%d %H:%M:%S"))
    df["Fault_Label"] = label
    return df


# ====================== COMPARE CURRENT ROW WITH PREVIOUS ROWS ======================
def make_features(raw):
    """For every row: its value and how it differs from 1, 2, 3 and 10 rows ago and from the last-10 average.
    Uses only the current row and rows BEFORE it (never the future)."""
    raw = raw.astype(float); filled = raw.ffill(limit=FILL_LIMIT); f = {}
    for s in SENSORS:
        v = filled[s]
        f[s] = v
        f[s + "__chg1"] = v - v.shift(1)
        f[s + "__chg2"] = v - v.shift(2)
        f[s + "__chg3"] = v - v.shift(3)
        f[s + "__chg10"] = v - v.shift(10)
        f[s + "__vs_avg10"] = v - v.rolling(10, min_periods=3).mean()
        same = raw[s].groupby(raw[s].ne(raw[s].shift()).cumsum()).cumcount() + 1     # rows with the same value in a row
        f[s + "__same_for"] = same.clip(upper=SAME_LIMIT)
        f[s + "__missing"] = raw[s].isna().astype(int).rolling(10, min_periods=1).sum()
    return pd.DataFrame(f)

def future_fault(labels):
    """Teaching answer for row t: the first fault that appears in the next 8 rows (0 = none)."""
    y = np.asarray(labels, int); out = np.zeros(len(y), int)
    for t in range(len(y)):
        nxt = y[t + 1:t + AHEAD + 1]; nxt = nxt[nxt > 0]
        if len(nxt): out[t] = nxt[0]
    return out


# ====================== MODEL ======================
def train_model(X, y):
    counts = pd.Series(y).value_counts()
    weight = pd.Series(y).map({c: len(y) / (len(counts) * n) for c, n in counts.items()}).to_numpy()  # rare faults count more
    classes = np.unique(y)
    m = xgb.XGBClassifier(objective="multi:softprob", n_estimators=200, max_depth=3, learning_rate=0.05,
                          subsample=0.8, colsample_bytree=0.5, min_child_weight=2, reg_lambda=5,
                          eval_metric="mlogloss", random_state=42, n_jobs=-1)
    m.fit(X, np.searchsorted(classes, y), sample_weight=weight)
    m.fault_classes_ = classes
    return m

def probabilities(model, X, n_classes):
    p = model.predict_proba(X); full = np.zeros((len(p), n_classes)); full[:, model.fault_classes_] = p
    return full


# ====================== LIVE MONITOR (one row at a time) ======================
def num(x):  return "n/a" if pd.isna(x) else f"{round(float(x), 2):g}"      # 57 stays 57, 57.4 stays 57.4
def chg(x):  return "n/a" if pd.isna(x) else f"{round(float(x), 2):+g}"

class Monitor:
    """Give it one row of sensor readings; it answers with chance of fault, status, and why."""
    def __init__(self, model, columns, n_classes):
        self.model, self.cols, self.n = model, list(columns), n_classes
        self.buffer, self.history = deque(maxlen=BUFFER), deque(maxlen=max(WARN_ROWS, CRIT_ROWS))

    def push(self, reading):
        self.buffer.append({s: reading.get(s, np.nan) for s in SENSORS})
        raw = pd.DataFrame(list(self.buffer)).astype(float)
        F = make_features(raw)[self.cols].iloc[[-1]]; now = F.iloc[0]
        p = probabilities(self.model, F, self.n)[0]; chance = 1 - p[0]
        expected = int(np.argmax(p[1:]) + 1)
        self.history.append(chance); h = list(self.history)
        status = "OK"
        if len(h) >= WARN_ROWS and all(x >= WARN_CHANCE for x in h[-WARN_ROWS:]): status = "WARNING"
        if len(h) >= CRIT_ROWS and all(x >= CRIT_CHANCE for x in h[-CRIT_ROWS:]): status = "CRITICAL"

        notes = []
        for s in SENSORS:
            gap = 0
            for v in reversed(raw[s].tolist()):
                if np.isnan(v): gap += 1
                else: break
            if gap >= 1: notes.append(f"{s} missing {gap} row(s) - last known value used" if gap <= FILL_LIMIT
                                      else f"{s} missing {gap} rows - CHECK SENSOR")
            if now[s + "__same_for"] >= SAME_LIMIT: notes.append(f"{s} same value for {SAME_LIMIT}+ rows - CHECK SENSOR")
            if pd.notna(now[s]) and float(now[s]) == 0: notes.append(f"{s} is zero - CHECK SENSOR / operating condition")

        contrib = None
        if len(self.buffer) > 10 and chance >= REASON_CHANCE and expected in self.model.fault_classes_:            # which sensors pushed the model
            k = int(np.searchsorted(self.model.fault_classes_, expected))
            c = self.model.get_booster().predict(xgb.DMatrix(F), pred_contribs=True)
            c = c[0, :-1] if c.ndim == 2 else c[0, k, :-1]
            contrib = {}
            for i, name in enumerate(self.cols):
                s = name.split("__")[0]; contrib[s] = contrib.get(s, 0) + abs(float(c[i]))
        return {"chance": chance, "status": status, "expected": expected,
                "notes": notes, "contrib": contrib, "now": now}


# ====================== PRINTING HELPERS ======================
def reasons_text(info, top=3):
    if not info["contrib"]: return ""
    now, c = info["now"], info["contrib"]
    return "; ".join(f"{s} {num(now[s])} ({chg(now[s + '__chg3'])} in 3 rows, {chg(now[s + '__chg10'])} in 10 rows)"
                     for s in sorted(c, key=c.get, reverse=True)[:top])

def print_row(r):
    exp = f"expects FAULT {r['expected']}" if r["chance"] >= WARN_CHANCE else "no fault expected"
    moves = (("reason: " if r["chance"] >= WARN_CHANCE else "watching: ") + reasons_text(r["info"], 2)) if r["info"]["contrib"] else "normal variation"
    truth = "" if r["actual"] is None else ("  <-- REAL FAULT %d HAPPENS HERE" % r["actual"] if r["actual"] > 0 else "")
    print(f" row {r['row']:>5} {r['time'][-8:]} | chance {r['chance'] * 100:3.0f}% | {r['status']:<8} | {exp:<18} | {moves}{truth}")
    for n in r["new_notes"]: print(f"{'':>25}DATA NOTE: {n}")

def print_detail(r):
    now, c = r["info"]["now"], r["info"]["contrib"] or {}
    order = sorted(SENSORS, key=lambda s: -c.get(s, 0)); top = set(order[:3])
    print(f"\n   >>> {r['status']} raised at row {r['row']} ({r['time'][-8:]}): chance of FAULT {r['expected']} within next {AHEAD} rows = {r['chance'] * 100:.0f}%")
    print("   How each sensor is NOW compared with its earlier readings (+ = higher now, - = lower now):")
    print(f"   {'Sensor':<20}{'Now':>5}{'vs 1 row':>10}{'vs 2 rows':>11}{'vs 3 rows':>11}{'vs 10 rows':>12}{'vs avg of 10':>14}")
    for s in order:
        mark = "  <-- main reason" if s in top else ""
        print(f"   {s:<20}{num(now[s]):>5}{chg(now[s + '__chg1']):>10}{chg(now[s + '__chg2']):>11}{chg(now[s + '__chg3']):>11}"
              f"{chg(now[s + '__chg10']):>12}{chg(now[s + '__vs_avg10']):>14}{mark}")
    print()


# ====================== MAIN ======================
def main(train_csv=None, new_csv=None):
    os.makedirs(OUT, exist_ok=True)
    print("COMPLETE WORKFLOW" + __doc__.split("COMPLETE WORKFLOW")[1].rstrip()); print("=" * 100)

    # ---------- STEP 1: data ----------
    if train_csv is None:
        if not os.path.exists("engine_data.csv"):
            make_demo_data().to_csv("engine_data.csv", index=False)
            print("Created demo file: engine_data.csv (1000 rows)")
        train_csv = "engine_data.csv"
    df = pd.read_csv(train_csv)
    if "Timestamp" not in df.columns: df.insert(0, "Timestamp", [f"row {i + 1}" for i in range(len(df))])
    SENSORS[:] = [c for c in df.columns if c not in ("Timestamp", "Fault_Label")]
    for s in SENSORS: df[s] = pd.to_numeric(df[s], errors="coerce")
    labels = df["Fault_Label"].fillna(0).astype(int).to_numpy(); n_classes = int(labels.max()) + 1
    starts = lambda y: [t for t in range(len(y)) if y[t] > 0 and not (y[max(0, t - 10):t] > 0).any()]
    print(f"\nSTEP 1  DATA   {train_csv}: {len(df)} rows, {len(SENSORS)} sensors, {len(starts(labels))} faults, "
          f"{int(df[SENSORS].isna().sum().sum())} missing readings")
    print("        Fault_Label: " + ", ".join(f"{k} = {int((labels == k).sum())} rows" for k in range(n_classes)) + "   (0 = engine normal)")

    # ---------- compare rows + learn (printed in order below) ----------
    feats, y_future = make_features(df[SENSORS]), future_fault(labels)
    cut = int(len(df) * TRAIN_PART) if new_csv is None else len(df)
    train_rows = slice(10, cut - AHEAD)
    model = train_model(feats.iloc[train_rows], y_future[train_rows])

    # ---------- STEP 2: how the comparison works (real example) ----------
    first = next((t for t in starts(labels) if 30 < t < train_rows.stop), None)
    if first:
        imp = pd.Series(model.feature_importances_, feats.columns).groupby(lambda c: c.split("__")[0]).sum()
        best, t = imp.idxmax(), first
        vals = df.loc[t - 10:t, best].tolist()
        print(f"\nSTEP 2  COMPARING A ROW WITH PREVIOUS ROWS  (example: {best}, at the first fault in the learning rows)")
        print("        last 11 readings : " + " ".join(num(v) for v in vals) + "   <- the last one is NOW")
        print(f"        now              : {num(vals[-1])}")
        print(f"        vs 1 row ago     : {chg(feats.loc[t, best + '__chg1'])}      vs 2 rows ago : {chg(feats.loc[t, best + '__chg2'])}      "
              f"vs 3 rows ago : {chg(feats.loc[t, best + '__chg3'])}")
        print(f"        vs 10 rows ago   : {chg(feats.loc[t, best + '__chg10'])}      vs average of last 10 : {chg(feats.loc[t, best + '__vs_avg10'])}")
        if "n/a" in "".join(num(v) for v in vals): print("        (n/a = a missing reading; the last known value is used for the comparison)")
        print("        The model looks at these changes for ALL sensors together, not just one.")

    # ---------- STEP 3: learning ----------
    print(f"\nSTEP 3  LEARNING   Rows 1-{cut} (first {int(TRAIN_PART * 100)}%) are used for learning: what the sensor changes looked like before each fault.")

    # ---------- STEP 4: watching new rows one by one ----------
    if new_csv:
        new = pd.read_csv(new_csv)
        if "Timestamp" not in new.columns: new.insert(0, "Timestamp", [f"row {i + 1}" for i in range(len(new))])
        for s in SENSORS: new[s] = pd.to_numeric(new[s], errors="coerce") if s in new.columns else np.nan
        truth = new["Fault_Label"].fillna(0).astype(int).to_numpy() if "Fault_Label" in new.columns else None
        src = f"{new_csv} (new engine readings)"
    else:
        new = df.iloc[cut:].reset_index(drop=True); truth = labels[cut:]; src = f"rows {cut + 1}-{len(df)} of the same file (last {100 - int(TRAIN_PART * 100)}%, never seen while learning)"
    print(f"\nSTEP 4  LIVE WATCHING   Rows arrive one by one from {src}.  Fault_Label is hidden: only sensor readings go in.")
    offset = 0 if new_csv else cut                       # row numbers match the row numbers in the CSV file
    mon = Monitor(model, feats.columns, n_classes); rows = []; seen = set()
    if not new_csv:                                      # the monitor has been running: it already holds the last readings before row 701
        for j in range(cut - BUFFER, cut): mon.buffer.append({s: df.loc[j, s] for s in SENSORS})
    for i in range(len(new)):
        info = mon.push({s: new.loc[i, s] for s in SENSORS})
        keys = {(n.split(" ")[0], "missing" in n) for n in info["notes"]}
        new_notes = [n for n in info["notes"] if (n.split(" ")[0], "missing" in n) not in seen]; seen = keys
        rows.append({"idx": i, "row": offset + i + 1, "time": str(new.loc[i, "Timestamp"]), "chance": info["chance"], "status": info["status"],
                     "expected": info["expected"], "notes": info["notes"], "new_notes": new_notes, "info": info,
                     "actual": None if truth is None else int(truth[i])})

    # alarm episodes
    alarm = np.array([r["status"] != "OK" for r in rows]); eps, i = [], 0
    while i < len(alarm):
        if alarm[i]:
            j = i
            while j < len(alarm) and alarm[j]: j += 1
            eps.append((i, j - 1)); i = j
        else: i += 1
    onsets = starts(truth) if truth is not None else []
    outcome = {}                                          # for every warning: did a real fault follow shortly after it started?
    for (a_, b_) in eps:
        nxt = next((o for o in onsets if a_ < o <= max(a_ + AHEAD, b_ + 1) and o - a_ <= 2 * AHEAD), None)   # fault came within 8 rows of the warning
        if nxt is not None: outcome[(a_, b_)] = ("Warned in advance", nxt)
        elif truth is not None and (np.asarray(truth)[a_:b_ + 1] > 0).any(): outcome[(a_, b_)] = ("Fault was already in progress", None)
        else: outcome[(a_, b_)] = ("False warning", None)
    first_warning = {}                                    # real fault -> row index where its (earliest) warning began
    for (a_, b_), (what, o) in outcome.items():
        if what == "Warned in advance" and o not in first_warning: first_warning[o] = a_

    # story: the first 3 faults (or first 3 warnings if no labels are available)
    if truth is not None:
        print("        (Real fault labels are shown ONLY so you can check the warnings. The model never sees them.)")
        print(f"        Status needs the chance to stay high on several rows in a row, so a one-row spike does not raise an alarm.")
        for k, o in enumerate(onsets[:3], 1):
            print(f"\n--- Example {k}: real FAULT {truth[o]} starts at row {o + 1 + offset} " + "-" * 40)
            first_alarm = first_warning.get(o)
            for r in rows[max(0, o - 12):o + 3]:
                if r["idx"] == first_alarm: print_detail(r)
                print_row(r)
            print("   RESULT: " + (f"warning came {o - first_alarm} rows BEFORE the fault." if first_alarm is not None
                                   else "NO WARNING before this fault (missed)."))
    else:
        for k, (a, b) in enumerate(eps[:3], 1):
            print(f"\n--- Warning {k} " + "-" * 60); print_detail(rows[a])
            for r in rows[max(0, a - 3):min(len(rows), b + 2, a + 14)]: print_row(r)

    # ---------- STEP 5: results ----------
    warned = list(first_warning)
    notice = [o - first_warning[o] for o in warned]
    false_eps = [e for e, (what, _) in outcome.items() if what == "False warning"]
    print("\n" + "=" * 100 + "\nSTEP 5  RESULT")
    if truth is not None:
        pred = np.array([r["expected"] if r["chance"] >= 0.5 else 0 for r in rows])
        target = future_fault(truth)
        print(f"   Real faults in these rows            : {len(onsets)}")
        print(f"   Warned BEFORE the fault started      : {len(warned)}  ({100 * len(warned) / max(len(onsets), 1):.0f}%)")
        print(f"   Missed (no warning before the fault) : {len(onsets) - len(warned)}")
        print(f"   Average advance notice               : {np.mean(notice) if notice else 0:.1f} rows before the fault")
        print(f"   False warnings (no fault followed)   : {len(false_eps)}")
        print(f"   Row accuracy (fault type next {AHEAD} rows) : {100 * np.mean(pred == target):.0f}%   (most rows are normal, so judge by the warnings above)")
    else:
        print(f"   Warnings raised: {len(eps)}  (see output/warnings.csv)")

    # ---------- CSV files ----------
    rep = new[["Timestamp"] + SENSORS].copy(); rep.insert(0, "Row", range(offset + 1, offset + len(new) + 1))
    for s in SENSORS:                                                  # keep whole numbers whole, decimals as they are
        if (rep[s].dropna() % 1 == 0).all(): rep[s] = rep[s].astype("Int64")
    rep["Fault_Chance_%"] = [round(100 * r["chance"]) for r in rows]
    rep["Status"] = [r["status"] for r in rows]
    rep["Expected_Fault"] = [r["expected"] if r["chance"] >= WARN_CHANCE else 0 for r in rows]
    rep["Main_Reasons(when_chance>=30%)"] = [reasons_text(r["info"]) for r in rows]
    rep["Data_Notes"] = ["; ".join(r["notes"]) for r in rows]
    if truth is not None: rep["Real_Fault_Now(for_checking_only)"] = truth
    rep.to_csv(f"{OUT}/live_report.csv", index=False)

    w = []
    for a, b in eps:
        r = rows[a]; peak = "CRITICAL" if any(x["status"] == "CRITICAL" for x in rows[a:b + 1]) else "WARNING"
        row = {"Warning_Start_Row": a + 1 + offset, "Warning_Start_Time": r["time"], "Warning_Ends_Row": b + 1 + offset, "Highest_Level": peak,
               "Expected_Fault": r["expected"], "Max_Chance_%": round(100 * max(x["chance"] for x in rows[a:b + 1])),
               "Main_Reasons": reasons_text(r["info"])}
        if truth is not None:
            what, nxt = outcome[(a, b)]
            row["Fault_Really_Started_At_Row"] = nxt + 1 + offset if nxt is not None else ""
            row["Rows_Of_Advance_Notice"] = nxt - a if nxt is not None else ""
            row["Outcome"] = what
        w.append(row)
    pd.DataFrame(w).to_csv(f"{OUT}/warnings.csv", index=False)
    if truth is not None:
        pd.DataFrame([{"Real_faults": len(onsets), "Warned_before": len(warned), "Missed": len(onsets) - len(warned),
                       "Average_notice_rows": round(float(np.mean(notice)), 1) if notice else 0, "False_warnings": len(false_eps)}]
                     ).to_csv(f"{OUT}/summary.csv", index=False)
    print(f"\nFILES (folder '{OUT}'):  live_report.csv (every row: readings, chance, status, reasons)   "
          f"warnings.csv (each warning" + (" and what really happened)   summary.csv" if truth is not None else ")"))


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", help="CSV to learn from (sensor columns + Fault_Label)")
    ap.add_argument("--new", help="CSV of NEW engine readings to watch (sensor columns only)")
    a = ap.parse_args(); main(a.data, a.new)
