MARINE ENGINE EARLY WARNING - XGBOOST
=====================================

RUN
  pip install -r requirements.txt
  python early_warning.py

ONE DATASET
  engine_data.csv = 1000 rows, 10 sensors, Timestamp and Fault_Label.
  Rows 1-700 are used for learning.
  Rows 701-1000 are treated as unseen/live test readings.
  Fault_Label is NOT supplied to the model during live prediction.

WORKFLOW
  1. Clean incoming sensor readings.
     - Missing value: use the last known value for up to 3 rows.
     - More than 3 missing rows: DATA NOTE says CHECK SENSOR.
     - Same value for 10+ rows: DATA NOTE says CHECK SENSOR.
     - Zero reading: DATA NOTE says CHECK SENSOR / operating condition.

  2. Compare each sensor with:
     - 1 row ago
     - 2 rows ago
     - 3 rows ago
     - 10 rows ago
     - average of the last 10 rows

  3. XGBoost predicts the first fault likely to occur in the NEXT 8 rows.

  4. Warning rules:
     - WARNING: fault chance >= 50% for 3 consecutive rows.
     - CRITICAL: fault chance >= 80% for 2 consecutive rows.

  5. When fault chance >= 30%, the report explains the main sensor reasons
     and shows how those sensors changed over 3 and 10 rows.

  6. The test section also checks:
     - faults warned before onset
     - missed faults
     - false warnings
     - average advance notice

DEMO DATA CONDITIONS INCLUDED
  - Normal operation
  - Faults 1-4
  - Gradual pre-fault trends
  - One deliberate false-warning pattern
  - One sudden fault with no useful pre-fault trend (missed-warning example)
  - Missing readings, including a gap longer than the 3-row fill limit
  - Sensor value frozen for more than 10 rows
  - Zero sensor readings
  - Recovery after faults

CURRENT DEMO RESULT
  Held-out chronological test: 300 rows
  Row accuracy for the next-8-row fault target: 90%
  Real faults in test: 5
  Warned before fault: 4
  Missed: 1
  Average advance notice: 5.8 rows
  False warnings: 1

IMPORTANT
  This is simulated demonstration data. The 90% result is NOT real-engine accuracy.
  When real engine data is supplied, evaluate the same workflow on the real data.
  Do not feed Fault_Label into the live prediction features.
